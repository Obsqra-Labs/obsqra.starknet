"use client";

import { useState, useEffect } from "react";
import { ProtocolPanel } from "@/components/zkdefi/ProtocolPanel";
import { ActivityLog } from "@/components/zkdefi/ActivityLog";
import { CompliancePanel } from "@/components/zkdefi/CompliancePanel";
import { PrivateTransferPanel } from "@/components/zkdefi/PrivateTransferPanel";
import { ConnectButton } from "@/components/zkdefi/ConnectButton";
import { PositionChart } from "@/components/zkdefi/PositionChart";
import { SessionKeyManager } from "@/components/zkdefi/SessionKeyManager";
import { AgentRebalancer } from "@/components/zkdefi/AgentRebalancer";
import { useAccount } from "@starknet-react/core";
import { Wallet, Shield, Key, RefreshCw, Brain } from "lucide-react";
import { OnboardingModal } from "@/components/zkdefi/OnboardingModal";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8003";

type MainTab = "agent" | "sessions" | "rebalance";
type ActionTab = "deposit" | "withdraw" | "private";
type ProtocolId = "pools" | "ekubo" | "jediswap";

const PROTOCOLS: { id: ProtocolId; name: string }[] = [
  { id: "pools", name: "Pools" },
  { id: "ekubo", name: "Ekubo" },
  { id: "jediswap", name: "JediSwap" },
];

export default function AgentPage() {
  const [mainTab, setMainTab] = useState<MainTab>("agent");
  const [activeTab, setActiveTab] = useState<ActionTab>("private");
  const [selectedProtocol, setSelectedProtocol] = useState<ProtocolId>("pools");
  const { address, isConnected } = useAccount();
  const [summaryPosition, setSummaryPosition] = useState<string | null>(null);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [positions, setPositions] = useState<{ [key: string]: number }>({});
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!mounted || !isConnected || !address) {
      if (!isConnected || !address) setSummaryPosition(null);
      return;
    }
    fetch(`${API_BASE}/api/v1/zkdefi/position/${address}?protocol_id=0`)
      .then((r) => r.json())
      .then((d) => {
        setSummaryPosition(d.position ?? "—");
        // Also fetch positions for all protocols
        setPositions({ pools: parseInt(d.position) || 0 });
      })
      .catch(() => setSummaryPosition("—"));
  }, [mounted, address, isConnected]);

  // Avoid hydration mismatch: server and first client paint show same shell (no wallet-dependent UI)
  const showWalletContent = mounted;

  return (
    <main className="min-h-screen bg-surface-0 text-white">
      <OnboardingModal />
      {/* Header */}
      <header className="border-b border-zinc-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">zkde.fi</h1>
              <p className="text-xs text-zinc-400">Privacy-preserving DeFi agent</p>
            </div>
          </div>
          <ConnectButton />
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {!showWalletContent ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
        {/* Position Summary Card - only after mount to avoid hydration #418 */}
        {isConnected && (
          <div className="glass rounded-2xl border border-zinc-800 p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-zinc-400 mb-1">Total Position</p>
                <p className="text-3xl font-bold">{summaryPosition ?? "—"}</p>
              </div>
              <div className="flex items-center gap-4">
                {activeSessionId && (
                  <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-violet-500/10 border border-violet-500/30">
                    <Key className="w-4 h-4 text-violet-400" />
                    <span className="text-xs font-medium text-violet-400">Session Active</span>
                  </div>
                )}
                <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30">
                  <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  <span className="text-xs font-medium text-amber-400">Sepolia Testnet</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Navigation Tabs */}
        <div className="flex gap-2 mb-6 border-b border-zinc-800 pb-4">
          <button
            onClick={() => setMainTab("agent")}
            className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
              mainTab === "agent"
                ? "bg-emerald-600 text-white"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Shield className="w-4 h-4" />
            Agent
          </button>
          <button
            onClick={() => setMainTab("sessions")}
            className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
              mainTab === "sessions"
                ? "bg-violet-600 text-white"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Key className="w-4 h-4" />
            Session Keys
          </button>
          <button
            onClick={() => setMainTab("rebalance")}
            className={`px-6 py-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
              mainTab === "rebalance"
                ? "bg-cyan-600 text-white"
                : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
            }`}
          >
            <Brain className="w-4 h-4" />
            zkML Rebalancer
          </button>
        </div>

        {/* Main Content Based on Tab */}
        {mainTab === "agent" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mb-6 lg:mb-8">
            <div className="lg:col-span-2 order-2 lg:order-1">
              <div className="glass rounded-2xl border border-zinc-800 p-6 mb-6">
              {/* Primary: Private Transfer Panel */}
              <div className="glass rounded-2xl border border-violet-800/50 p-6 mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="w-5 h-5 text-violet-400" />
                  <h2 className="text-xl font-semibold">Private Transfer</h2>
                  <span className="ml-auto px-2 py-1 text-xs rounded bg-violet-600/20 text-violet-300 border border-violet-600/30">
                    Default
                  </span>
                </div>
                <PrivateTransferPanel />
              </div>

              {/* Secondary: Proof-Gated Actions */}
              <div className="glass rounded-2xl border border-zinc-800 p-6 mb-6">
                <div className="flex gap-2 mb-6 border-b border-zinc-800 pb-4">
                  <button
                    onClick={() => setActiveTab("deposit")}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === "deposit"
                        ? "bg-emerald-600 text-white"
                        : "text-zinc-400 hover:text-zinc-200"
                    }`}
                  >
                    Proof-Gated Deposit
                  </button>
                  <button
                    onClick={() => setActiveTab("withdraw")}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === "withdraw"
                        ? "bg-emerald-600 text-white"
                        : "text-zinc-400 hover:text-zinc-200"
                    }`}
                  >
                    Withdraw
                  </button>
                </div>

                {activeTab !== "private" && (
                  <>
                    <div className="mb-2">
                      <p className="text-xs text-zinc-500">
                        {activeTab === "deposit" ? "Choose protocol (where to deposit)" : "Choose protocol (where to withdraw from)"}
                      </p>
                    </div>
                    <div className="flex gap-2 mb-6">
                      {PROTOCOLS.map((protocol) => (
                        <button
                          key={protocol.id}
                          onClick={() => setSelectedProtocol(protocol.id)}
                          className={`px-4 py-2 rounded-lg font-medium transition-all ${
                            selectedProtocol === protocol.id
                              ? "bg-zinc-800 text-white border border-zinc-700"
                              : "text-zinc-400 hover:text-zinc-200 border border-transparent"
                          }`}
                        >
                          {protocol.name}
                        </button>
                      ))}
                    </div>
                    <ProtocolPanel protocolId={selectedProtocol} />
                  </>
                )}
              </div>
              </div>

              {/* Activity Feed */}
              <ActivityLog />
            </div>

            {/* Sidebar */}
            <div className="space-y-6 order-1 lg:order-2">
              <PositionChart />
              <CompliancePanel />
            </div>
          </div>
        )}

        {mainTab === "sessions" && address && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
            <div className="lg:col-span-2">
              <SessionKeyManager 
                userAddress={address} 
                onSessionGranted={(sessionId) => setActiveSessionId(sessionId)}
              />
            </div>
            <div className="space-y-6">
              <div className="glass rounded-2xl border border-zinc-800 p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Key className="w-5 h-5 text-violet-400" />
                  About Session Keys
                </h3>
                <div className="space-y-3 text-sm text-zinc-400">
                  <p>Session keys enable <span className="text-white">autonomous agent execution</span> without exposing your main wallet.</p>
                  <p>The agent can only act within your <span className="text-violet-400">defined constraints</span>:</p>
                  <ul className="list-disc list-inside space-y-1 text-zinc-500">
                    <li>Maximum position size</li>
                    <li>Allowed protocols only</li>
                    <li>Time-limited duration</li>
                  </ul>
                  <p className="text-xs text-zinc-500 pt-2">All actions are proof-gated and create on-chain receipts.</p>
                </div>
              </div>
              <CompliancePanel />
            </div>
          </div>
        )}

        {mainTab === "rebalance" && showWalletContent && address && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
            <div className="lg:col-span-2">
              <AgentRebalancer 
                userAddress={address}
                sessionId={activeSessionId ?? undefined}
                positions={positions}
              />
            </div>
            <div className="space-y-6">
              <div className="glass rounded-2xl border border-zinc-800 p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Brain className="w-5 h-5 text-cyan-400" />
                  zkML Gating
                </h3>
                <div className="space-y-3 text-sm text-zinc-400">
                  <p>Every rebalance is checked by <span className="text-cyan-400">privacy-preserving ML models</span>:</p>
                  <div className="space-y-2">
                    <div className="bg-zinc-800/50 rounded-lg p-3 border border-zinc-700/50">
                      <p className="text-white text-sm mb-1">Risk Score Model</p>
                      <p className="text-xs text-zinc-500">Evaluates portfolio risk without revealing positions</p>
                    </div>
                    <div className="bg-zinc-800/50 rounded-lg p-3 border border-zinc-700/50">
                      <p className="text-white text-sm mb-1">Anomaly Detector</p>
                      <p className="text-xs text-zinc-500">Checks target pool for rug/exploit signals</p>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-500 pt-2">Proofs verified on-chain via Garaga (Groth16)</p>
                </div>
              </div>
              <PositionChart />
            </div>
          </div>
        )}

        {!isConnected && mainTab !== "agent" && (
          <div className="text-center py-20">
            <Shield className="w-16 h-16 mx-auto mb-4 text-zinc-600" />
            <h2 className="text-2xl font-bold mb-2">Connect Wallet</h2>
            <p className="text-zinc-400 mb-6">Connect your wallet to access session keys and rebalancer</p>
            <ConnectButton />
          </div>
        )}
          </>
        )}
      </div>
    </main>
  );
}
